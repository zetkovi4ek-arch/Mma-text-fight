plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android { namespace = "com.example.mmatextbattles"; compileSdk = 35
    defaultConfig { applicationId = "com.example.mmatextbattles"; minSdk = 24; targetSdk = 35; versionCode = 1; versionName = "2.0" }
}
