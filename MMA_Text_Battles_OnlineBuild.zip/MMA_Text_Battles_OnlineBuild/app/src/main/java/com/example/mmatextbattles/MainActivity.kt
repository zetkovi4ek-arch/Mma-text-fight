package com.example.mmatextbattles

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlin.random.Random

data class Fighter(var name:String,var division:String,var rating:Int,var w:Int=0,var l:Int=0,var ko:Int=0,var sub:Int=0,var dec:Int=0)

class MainActivity: android.app.Activity() {
    private lateinit var content: LinearLayout
    private val fighters = mutableListOf(
        Fighter("Алекс Волков","Тяжёлый",88,12,3,6,2,4),
        Fighter("Магомед Орлов","Полусредний",91,15,2,7,5,3),
        Fighter("Илья Громов","Лёгкий",84,10,4,4,3,3),
        Fighter("Даниил Карпов","Средний",86,11,5,5,2,4)
    )
    private val divisions = arrayOf("Наилегчайший","Легчайший","Полулёгкий","Лёгкий","Полусредний","Средний","Полутяжёлый","Тяжёлый")
    private val methods = arrayOf("KO","TKO","SUB","DEC","DQ")
    private val rounds = arrayOf("1","2","3","4","5")

    override fun onCreate(b:Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_main)
        content=findViewById(R.id.content)
        val mode=findViewById<Spinner>(R.id.mode)
        mode.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,
            arrayOf("🥊 Провести бой","🏆 Рейтинги","👤 Бойцы","🎲 Случайный бой"))
        mode.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(p:AdapterView<*>?) {}
            override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){render(pos)}
        }
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(4,4,4,24)
    }
    private fun tv(s:String,size:Float=16f)=TextView(this).apply{
        text=s; textSize=size; setTextColor(Color.WHITE); setPadding(4,8,4,8)
    }
    private fun field(hint:String)=EditText(this).apply{
        this.hint=hint; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setSingleLine()
    }
    private fun btn(text:String,action:()->Unit)=Button(this).apply{
        this.text=text; setOnClickListener{action()}
    }
    private fun add(x:View){content.addView(x)}

    private fun render(mode:Int){
        content.removeAllViews()
        when(mode){0->fightForm();1->rankings();2->fighterList();3->randomFight()}
    }

    private fun fightForm(){
        val box=base(); val a=field("Соперник 1"); val c=field("Соперник 2")
        box.addView(a); box.addView(c)
        val div=Spinner(this); div.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,divisions); box.addView(div)
        val win=Spinner(this); win.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Соперник 1","Соперник 2")); box.addView(win)
        val method=Spinner(this); method.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,methods); box.addView(method)
        val round=Spinner(this); round.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,rounds); box.addView(round)
        box.addView(btn("ЗАПИСАТЬ БОЙ"){ 
            if(a.text.isBlank()||c.text.isBlank()){Toast.makeText(this,"Введи имена обоих бойцов",Toast.LENGTH_SHORT).show();return@btn}
            val winner=if(win.selectedItemPosition==0)a.text.toString() else c.text.toString()
            val loser=if(win.selectedItemPosition==0)c.text.toString() else a.text.toString()
            val m=method.selectedItem.toString()
            val r=round.selectedItem.toString()
            val f=fighters.find{it.name.equals(winner,true)} ?: Fighter(winner,div.selectedItem.toString(),80).also{fighters.add(it)}
            val l=fighters.find{it.name.equals(loser,true)} ?: Fighter(loser,div.selectedItem.toString(),80).also{fighters.add(it)}
            f.w++; l.l++
            when(m){ "KO","TKO"->f.ko++; "SUB"->f.sub; "DEC"->f.dec }
            f.rating=(f.rating+2).coerceAtMost(99); l.rating=(l.rating-1).coerceAtLeast(1)
            Toast.makeText(this,"${winner} победил ${loser} — $m, раунд $r",Toast.LENGTH_LONG).show()
            a.text.clear(); c.text.clear()
        })
        add(box)
    }

    private fun rankings(){
        val box=base(); box.addView(tv("РЕЙТИНГ P4P",22f))
        fighters.sortedByDescending{it.rating}.forEachIndexed{ i,f->
            box.addView(tv("${i+1}. ${f.name}  •  ${f.rating}  |  ${f.w}-${f.l}"))
        }
        add(box)
    }
    private fun fighterList(){
        val box=base(); box.addView(tv("БОЙЦЫ И СТАТИСТИКА",22f))
        fighters.forEach{f->
            box.addView(tv("${f.name}\n${f.division} • Рейтинг ${f.rating}\nРекорд ${f.w}-${f.l} | KO/TKO: ${f.ko} | SUB: ${f.sub} | DEC: ${f.dec}"))
        }
        add(box)
    }
    private fun randomFight(){
        val box=base(); box.addView(tv("ГЕНЕРАТОР СЛУЧАЙНОГО БОЯ",22f))
        val div=Spinner(this); div.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,divisions); box.addView(div)
        val result=tv("Нажми кнопку — приложение сгенерирует бой.",17f); box.addView(result)
        box.addView(btn("🎲 СГЕНЕРИРОВАТЬ БОЙ"){
            val pool=fighters.filter{it.division==div.selectedItem.toString()}
            val x=if(pool.size>=2) pool.shuffled().take(2) else fighters.shuffled().take(2)
            val w=x[Random.nextInt(2)]; val l=x.first{it!=w}
            val m=methods[Random.nextInt(methods.size)]; val r=rounds[Random.nextInt(rounds.size)]
            val line=when(m){
                "KO"->"${w.name} поймал момент в стойке и завершил бой нокаутом."
                "TKO"->"${w.name} забрал эпизод за эпизодом, после чего рефери остановил бой."
                "SUB"->"${w.name} перевёл соперника, вышел на приём и заставил сдаться."
                "DEC"->"${w.name} выиграл бой по очкам после пяти раундов."
                else->"${w.name} победил после дисквалификации соперника."
            }
            result.text="${w.name} vs ${l.name}\n\nПОБЕДИТЕЛЬ: ${w.name}\nМЕТОД: $m\nРАУНД: $r\n\n$line"
        })
        add(box)
    }
}